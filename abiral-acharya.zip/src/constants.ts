/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Service, Testimonial, BlogPost, FAQItem } from './types';

export const SERVICES: Service[] = [
  {
    id: 'general-checkup',
    title: 'General Checkup',
    description: 'Comprehensive health evaluations for prevention and early detection of illnesses.',
    icon: 'Stethoscope'
  },
  {
    id: 'child-care',
    title: 'Child Care',
    description: 'Expert medical care for infants, children, and adolescents to ensure healthy development.',
    icon: 'Baby'
  },
  {
    id: 'diabetes-management',
    title: 'Diabetes Management',
    description: 'Personalized treatment plans and monitoring for effective diabetes control.',
    icon: 'Activity'
  },
  {
    id: 'heart-health',
    title: 'Heart Health',
    description: 'Cardiac screening and management to maintain optimal cardiovascular health.',
    icon: 'HeartPulse'
  },
  {
    id: 'vaccination',
    title: 'Vaccination',
    description: 'Full range of immunizations for children and adults according to medical guidelines.',
    icon: 'Syringe'
  },
  {
    id: 'online-consultation',
    title: 'Online Consultation',
    description: 'Virtual medical advice and follow-up from the comfort of your home.',
    icon: 'Video'
  },
  {
    id: 'emergency-care',
    title: 'Emergency Care',
    description: 'Prompt medical attention for acute illnesses and injuries during clinic hours.',
    icon: 'Ambulance'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    role: 'Patient',
    content: 'Dr. Miller is exceptionally thorough and compassionate. The clinic staff is professional and welcoming. Highly recommended!',
    rating: 5,
    image: 'https://picsum.photos/seed/patient1/100/100'
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'Parent',
    content: 'Best pediatric care in the city. My son actually looks forward to his visits. Truly a child-friendly environment.',
    rating: 5,
    image: 'https://picsum.photos/seed/patient2/100/100'
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: '1',
    title: '5 Tips for a Healthier Heart',
    excerpt: 'Simple lifestyle changes that can significantly reduce your risk of cardiovascular disease.',
    date: 'May 1, 2024',
    category: 'Wellness',
    image: 'https://picsum.photos/seed/health1/800/600'
  },
  {
    id: '2',
    title: 'Managing Seasonal Allergies',
    excerpt: 'How to identify triggers and find relief during high pollen seasons.',
    date: 'April 15, 2024',
    category: 'Information',
    image: 'https://picsum.photos/seed/health2/800/600'
  }
];

export const FAQS: FAQItem[] = [
  {
    question: 'How do I book an appointment?',
    answer: 'You can book an appointment through our online booking form, by calling our clinic, or via WhatsApp.'
  },
  {
    question: 'Do you accept insurance?',
    answer: 'Yes, we accept most major health insurance plans. Please contact our front desk for specific coverage details.'
  },
  {
    question: 'What are your clinic hours?',
    answer: 'We are open Monday to Friday from 9:00 AM to 6:00 PM, and Saturday from 9:00 AM to 1:00 PM.'
  }
];
