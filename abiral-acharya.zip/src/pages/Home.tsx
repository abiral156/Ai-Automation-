/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { 
  ArrowRight, 
  Stethoscope, 
  Baby, 
  Activity, 
  HeartPulse, 
  Syringe, 
  Video, 
  Ambulance,
  CheckCircle2,
  Phone,
  Clock,
  ShieldCheck,
  Star
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { SERVICES, TESTIMONIALS, FAQS } from '../constants';
import { cn } from '../lib/utils';

const ICON_MAP: Record<string, React.ReactNode> = {
  Stethoscope: <Stethoscope size={24} />,
  Baby: <Baby size={24} />,
  Activity: <Activity size={24} />,
  HeartPulse: <HeartPulse size={24} />,
  Syringe: <Syringe size={24} />,
  Video: <Video size={24} />,
  Ambulance: <Ambulance size={24} />,
};

export default function Home() {
  return (
    <div className="space-y-24 pb-20">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://picsum.photos/seed/doctor1/1920/1080?grayscale&blur=2"
            alt="Clinic Hero"
            className="w-full h-full object-cover opacity-10"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-white via-white/95 to-transparent" />
        </div>

        <div className="max-w-7xl mx-auto px-10 lg:px-12 relative z-10 w-full grid lg:grid-cols-2 items-center gap-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="space-y-6"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold uppercase tracking-wider border border-green-200">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              Accepting New Patients
            </div>
            <h1 className="text-6xl lg:text-7xl font-extrabold tracking-tight text-slate-900 leading-[1.1]">
              Compassionate <br/>Healthcare <span className="text-blue-600">You Can Trust</span>
            </h1>
            <p className="text-lg text-slate-600 leading-relaxed max-w-md">
              Providing specialized medical care with a focus on patient comfort, advanced diagnostics, and personalized treatment plans for your family.
            </p>
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <Link
                to="/appointment"
                className="bg-blue-600 text-white px-8 py-3.5 rounded-xl font-bold text-lg hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 flex items-center gap-2 group"
              >
                Book Appointment
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/services"
                className="bg-white text-slate-700 border border-slate-300 px-8 py-3.5 rounded-xl font-bold text-lg hover:bg-slate-50 transition-all"
              >
                Our Services
              </Link>
            </div>
            <div className="flex items-center gap-8 pt-4">
              <div className="flex -space-x-4">
                {[1, 2, 3, 4].map((i) => (
                  <img
                    key={i}
                    src={`https://picsum.photos/seed/face${i}/100/100`}
                    className="w-12 h-12 rounded-full border-4 border-white shadow-sm"
                    referrerPolicy="no-referrer"
                  />
                ))}
              </div>
              <div className="text-sm">
                <div className="flex text-amber-400 mb-1">
                  {[1, 2, 3, 4, 5].map((i) => <Star key={i} size={14} fill="currentColor" />)}
                </div>
                <p className="text-slate-500 font-medium">Joined by 2,000+ Happy Patients</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="relative z-10 rounded-[2.5rem] overflow-hidden shadow-2xl border-8 border-white">
              <img
                src="https://picsum.photos/seed/doctor-hero/800/1000"
                alt="Expert Doctor"
                className="w-full h-auto aspect-[4/5] object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Floating Stats */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -top-6 -right-6 bg-white p-6 rounded-3xl shadow-xl z-20 border border-slate-100"
            >
              <div className="text-blue-600 font-bold text-3xl mb-1">15+</div>
              <div className="text-slate-500 text-xs font-bold uppercase tracking-wider">Years Experience</div>
            </motion.div>
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
              className="absolute -bottom-6 -left-6 bg-white p-6 rounded-3xl shadow-xl z-20 border border-slate-100"
            >
              <div className="flex items-center gap-3">
                <div className="bg-emerald-50 p-2 rounded-xl text-emerald-600">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <div className="text-slate-900 font-bold">100% Secure</div>
                  <div className="text-slate-500 text-xs text-nowrap tracking-wide">Patient Privacy Ensured</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Quick Quick Info */}
      <section className="max-w-7xl mx-auto px-6 lg:px-8 -mt-20 relative z-30">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: Phone, title: 'Emergency Contact', desc: '+1 (555) 911-HELP', color: 'bg-rose-50 text-rose-600' },
            { icon: Clock, title: 'Opening Hours', desc: 'Mon - Sat: 9AM - 6PM', color: 'bg-blue-50 text-blue-600' },
            { icon: MapPin, title: 'Our Location', desc: 'Health Plaza, Suite 400', color: 'bg-emerald-50 text-emerald-600' },
          ].map((item, idx) => (
            <div key={idx} className="bg-white p-8 rounded-3xl shadow-lg border border-slate-100 flex items-center gap-6">
              <div className={cn('p-4 rounded-2xl', item.color)}>
                <item.icon size={32} />
              </div>
              <div>
                <h3 className="text-slate-500 text-sm font-bold uppercase tracking-wider mb-1">{item.title}</h3>
                <p className="text-slate-900 font-bold text-xl">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Services Overview */}
      <section className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center space-y-4 mb-20">
          <span className="text-blue-600 font-bold uppercase tracking-[0.2em] text-sm">Specializations</span>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight">Our Premium Medical Services</h2>
          <p className="text-slate-500 max-w-2xl mx-auto leading-relaxed">
            We offer a wide range of specialized medical services tailored to your needs, using the latest technologies and compassionate care approaches.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICES.slice(0, 4).map((service, idx) => (
            <motion.div
              key={service.id}
              whileHover={{ y: -4 }}
              className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100 hover:shadow-xl transition-all group"
            >
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300 font-bold italic">
                {service.title.substring(0, 2)}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">{service.title}</h3>
              <p className="text-sm text-slate-500 leading-relaxed mb-6">
                {service.description}
              </p>
              <Link to="/services" className="text-blue-600 text-sm font-bold flex items-center gap-2 group/link">
                Learn More
                <ArrowRight size={16} className="group-hover/link:translate-x-1 transition-transform" />
              </Link>
            </motion.div>
          ))}
        </div>
        <div className="mt-16 text-center">
          <Link
            to="/services"
            className="inline-flex items-center gap-2 text-slate-600 font-bold px-8 py-3 rounded-full hover:bg-slate-100 transition-all border border-slate-200"
          >
            Check All Services
          </Link>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-slate-900 py-32 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-blue-500/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-emerald-500/10 blur-[100px] rounded-full" />
        
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <div className="space-y-10">
              <div className="space-y-4">
                <span className="text-blue-400 font-bold uppercase tracking-[0.2em] text-sm">Success Stories</span>
                <h2 className="text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight">
                  What Our Patients <br /> Say About Us
                </h2>
              </div>
              <div className="space-y-12">
                {TESTIMONIALS.map((t) => (
                  <motion.div
                    key={t.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="space-y-6"
                  >
                    <div className="flex text-amber-400">
                      {[1, 2, 3, 4, 5].map((i) => <Star key={i} size={18} fill="currentColor" />)}
                    </div>
                    <p className="text-2xl text-slate-300 italic leading-relaxed">
                      "{t.content}"
                    </p>
                    <div className="flex items-center gap-4">
                      <img
                        src={t.image}
                        alt={t.name}
                        className="w-14 h-14 rounded-full border-2 border-slate-700"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <div className="text-white font-bold text-lg">{t.name}</div>
                        <div className="text-slate-500 text-sm">{t.role}</div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="rounded-[3rem] overflow-hidden aspect-square">
                <img
                  src="https://picsum.photos/seed/clinic-room/1000/1000"
                  alt="Modern Clinic"
                  className="w-full h-full object-cover grayscale opacity-40 hover:grayscale-0 hover:opacity-100 transition-all duration-700 cursor-pointer"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-10 -right-10 bg-blue-600 p-12 rounded-[2.5rem] shadow-2xl hidden md:block">
                <div className="text-white text-6xl font-bold mb-2">98%</div>
                <div className="text-blue-200 font-bold uppercase tracking-widest text-xs">Patient Satisfaction</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="max-w-4xl mx-auto px-6 lg:px-8 py-10">
        <div className="text-center space-y-4 mb-20">
          <span className="text-blue-600 font-bold uppercase tracking-[0.2em] text-sm">Common Queries</span>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-6">
          {FAQS.map((faq, idx) => (
            <details key={idx} className="group bg-white rounded-3xl border border-slate-100 overflow-hidden transition-all shadow-sm open:shadow-md">
              <summary className="p-8 font-bold text-xl cursor-pointer list-none flex items-center justify-between hover:text-blue-600 transition-colors">
                {faq.question}
                <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center group-open:rotate-180 transition-transform">
                  <ArrowRight size={18} className="rotate-90" />
                </div>
              </summary>
              <div className="px-8 pb-8 text-slate-500 leading-relaxed text-lg">
                {faq.answer}
              </div>
            </details>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="bg-blue-600 rounded-[3.5rem] p-12 lg:p-24 text-center relative overflow-hidden shadow-2xl shadow-blue-200">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.1),transparent)]" />
          <div className="relative z-10 space-y-10">
            <h2 className="text-4xl lg:text-6xl font-bold text-white tracking-tight">Ready to Prioritize Your Health?</h2>
            <p className="text-blue-100 text-xl max-w-2xl mx-auto leading-relaxed">
              Book your appointment today and take the first step towards a healthier you. Our team is ready to welcome you.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-6">
              <Link
                to="/appointment"
                className="bg-white text-blue-600 px-10 py-5 rounded-2xl font-bold text-xl hover:bg-slate-50 transition-all shadow-xl flex items-center gap-2 group"
              >
                Book Your Appointment
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <a
                href="tel:+15550001111"
                className="text-white font-bold flex items-center gap-3 px-10 py-5 rounded-2xl border border-white/30 hover:bg-white/10 transition-all"
              >
                <div className="bg-white/20 p-2 rounded-full">
                  <Phone size={20} />
                </div>
                +1 (555) 000-1111
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function MapPin(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
