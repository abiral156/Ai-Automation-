/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Award, GraduationCap, Calendar, Briefcase, CheckCircle2, ChevronRight } from 'lucide-react';

export default function About() {
  return (
    <div className="space-y-32 pb-32">
      {/* Intro Header */}
      <section className="max-w-7xl mx-auto px-10 lg:px-12 mt-20">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-bold uppercase tracking-wider border border-green-200">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              Chief Medical Officer
            </div>
            <h1 className="text-6xl lg:text-7xl font-extrabold tracking-tight text-slate-900 leading-[1.1]">
              Dedicated to <span className="text-blue-600">Your Health</span> & Wellbeing
            </h1>
            <p className="text-lg text-slate-600 leading-relaxed">
              Dr. Abiral Acharya has been serving the community for over 12 years, blending cutting-edge technology with traditional care values to ensure every patient feels heard and healed.
            </p>
            <div className="grid grid-cols-2 gap-6 max-w-sm">
              <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm transition-shadow">
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-1">Experience</p>
                <p className="text-xl font-bold text-slate-900">12+ Years</p>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm transition-shadow">
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-1">Rating</p>
                <p className="text-xl font-bold text-slate-900">4.9/5.0</p>
              </div>
            </div>
          </div>
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative"
          >
            <div className="aspect-square rounded-[32px] overflow-hidden shadow-2xl relative z-10 border-8 border-white grayscale hover:grayscale-0 transition-all duration-700">
              <img
                src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=800"
                alt="Dr. Abiral Acharya"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-8 -left-8 bg-white p-8 rounded-[32px] shadow-2xl border border-slate-100 z-20 max-w-xs">
              <p className="text-slate-600 leading-snug italic text-sm">
                "My mission is to blend cutting-edge technology with traditional care values."
              </p>
              <div className="mt-2 text-slate-500 font-medium text-xs">— Dr. Abiral Acharya</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Qualifications Grid */}
      <section className="bg-slate-50 py-32 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-20 space-y-4">
            <span className="text-blue-600 font-bold uppercase tracking-[0.2em] text-sm">Our Expertise</span>
            <h2 className="text-4xl font-bold tracking-tight text-slate-900">Education & Experience</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
            {[
              { 
                icon: GraduationCap, 
                title: 'Education', 
                items: ['MD from Harvard Medical School', 'Residency at Chicago General Hospital', 'Board Certified in Internal Medicine'] 
              },
              { 
                icon: Award, 
                title: 'Certifications', 
                items: ['Fellow of the American College of Physicians', 'Diplomate, American Board of Family Medicine', 'Advanced Cardiac Life Support (ACLS)'] 
              },
              { 
                icon: Briefcase, 
                title: 'Specializations', 
                items: ['Preventative Healthcare', 'Pediatric Patient Care', 'Complex Chronic Disease Management'] 
              },
            ].map((section, idx) => (
              <div key={idx} className="bg-white p-12 rounded-[2.5rem] shadow-sm border border-slate-100 space-y-8">
                <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
                  <section.icon size={32} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900">{section.title}</h3>
                <ul className="space-y-4">
                  {section.items.map((item, i) => (
                    <li key={i} className="flex gap-3 text-slate-500 leading-relaxed">
                      <ChevronRight size={20} className="shrink-0 text-blue-400 mt-1" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="max-w-4xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-20 space-y-4">
          <span className="text-blue-600 font-bold uppercase tracking-[0.2em] text-sm">Our Journey</span>
          <h2 className="text-4xl font-bold tracking-tight text-slate-900">Milestones in Excellence</h2>
        </div>

        <div className="space-y-12 relative before:absolute before:left-[1.875rem] before:top-0 before:bottom-0 before:w-px before:bg-slate-200">
          {[
            { year: '2012', title: 'Clinic Founded', desc: 'Dr. Abiral Acharya opened the clinic with a vision for personalized care.' },
            { year: '2016', title: 'Pediatric Center Opening', desc: 'Expanded our services with a dedicated wing for children.' },
            { year: '2020', title: 'Digital Transformation', desc: 'Launched our advanced online booking and AI-powered patient support.' },
            { year: '2024', title: 'Excellence in Care Award', desc: 'Recognized for top patient satisfaction scores in Chicago.' },
          ].map((mile, idx) => (
            <div key={idx} className="relative pl-20 group">
              <div className="absolute left-0 top-0 w-16 h-16 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center font-bold text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all z-10">
                {mile.year}
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-slate-900">{mile.title}</h3>
                <p className="text-slate-500 text-lg leading-relaxed">{mile.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
