/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Clock, User, Phone, Mail, Building2, MessageSquare, CheckCircle, ArrowRight } from 'lucide-react';
import { SERVICES } from '../constants';

export default function Appointment() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    date: '',
    time: '09:00',
    department: 'general-checkup',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form Submitted:', formData);
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="max-w-4xl mx-auto px-6 lg:px-8 py-24 text-center space-y-8">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-emerald-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto text-emerald-600 shadow-xl shadow-emerald-100"
        >
          <CheckCircle size={48} />
        </motion.div>
        <h1 className="text-4xl font-bold text-slate-900 tracking-tight">Appointment Request Received!</h1>
        <p className="text-xl text-slate-500 max-w-lg mx-auto">
          Thank you for choosing Abiral Acharya. Our team will contact you within 24 hours to confirm your appointment details.
        </p>
        <button
          onClick={() => setIsSubmitted(false)}
          className="bg-blue-600 text-white px-10 py-4 rounded-2xl font-bold text-lg hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 mt-10"
        >
          Back to Website
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
      <div className="grid lg:grid-cols-5 gap-20 items-start">
        <div className="lg:col-span-2 space-y-12">
          <div className="space-y-6">
            <h1 className="text-5xl font-bold tracking-tight text-slate-900 leading-tight">
              Book Your <span className="text-blue-600">Consultation</span> Online
            </h1>
            <p className="text-xl text-slate-500 leading-relaxed">
              Schedule your visit in seconds. Choose your preferred date, time, and department, and we'll handle the rest.
            </p>
          </div>

          <div className="space-y-6">
            <div className="flex gap-6 items-start">
              <div className="bg-blue-50 p-4 rounded-2xl text-blue-600 shrink-0">
                <Clock size={32} />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Clinic Timings</h3>
                <p className="text-slate-500">Mon - Fri: 9AM - 6PM</p>
                <p className="text-slate-500">Saturday: 9AM - 1PM</p>
              </div>
            </div>
            <div className="flex gap-6 items-start">
              <div className="bg-emerald-50 p-4 rounded-2xl text-emerald-600 shrink-0">
                <CheckCircle size={32} />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Instant Confirmation</h3>
                <p className="text-slate-500">We respond to all requests within one business day via call or email.</p>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 blur-2xl rounded-full" />
            <div className="relative z-10 space-y-6">
              <div className="text-blue-400 font-bold uppercase tracking-widest text-xs">Emergency Support</div>
              <p className="text-lg">If you have a medical emergency, please call us directly for immediate assistance.</p>
              <div className="text-2xl font-bold">+1 (555) 911-HELP</div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-3">
          <form onSubmit={handleSubmit} className="bg-white p-10 lg:p-14 rounded-[3.5rem] shadow-2xl border border-slate-100 space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-bold text-slate-500 uppercase tracking-wider ml-1">
                  <User size={14} /> Full Name
                </label>
                <input
                  required
                  type="text"
                  placeholder="John Doe"
                  className="w-full bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 rounded-2xl p-4 transition-all outline-none text-lg"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-bold text-slate-500 uppercase tracking-wider ml-1">
                  <Phone size={14} /> Phone Number
                </label>
                <input
                  required
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  className="w-full bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 rounded-2xl p-4 transition-all outline-none text-lg"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-bold text-slate-500 uppercase tracking-wider ml-1">
                <Mail size={14} /> Email Address
              </label>
              <input
                required
                type="email"
                placeholder="john@example.com"
                className="w-full bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 rounded-2xl p-4 transition-all outline-none text-lg"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-bold text-slate-500 uppercase tracking-wider ml-1">
                  <Calendar size={14} /> Preferred Date
                </label>
                <input
                  required
                  type="date"
                  className="w-full bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 rounded-2xl p-4 transition-all outline-none text-lg"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-bold text-slate-500 uppercase tracking-wider ml-1">
                  <Clock size={14} /> Preferred Time
                </label>
                <select
                  className="w-full bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 rounded-2xl p-4 transition-all outline-none text-lg cursor-pointer"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                >
                  {['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00'].map((t) => (
                    <option key={t} value={t}>{t} AM/PM</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-bold text-slate-500 uppercase tracking-wider ml-1">
                <Building2 size={14} /> Select Department
              </label>
              <select
                className="w-full bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 rounded-2xl p-4 transition-all outline-none text-lg cursor-pointer"
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
              >
                {SERVICES.map((s) => (
                  <option key={s.id} value={s.id}>{s.title}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-bold text-slate-500 uppercase tracking-wider ml-1">
                <MessageSquare size={14} /> Additional Notes
              </label>
              <textarea
                rows={4}
                placeholder="Briefly describe your symptoms or reason for visit..."
                className="w-full bg-slate-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-100 rounded-2xl p-4 transition-all outline-none text-lg resize-none"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              />
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-5 rounded-[2rem] font-bold text-xl hover:bg-blue-700 transition-all shadow-xl shadow-blue-200 flex items-center justify-center gap-3 group"
            >
              Confirm Appointment
              <ArrowRight className="group-hover:translate-x-1 transition-transform" />
            </button>

            <p className="text-center text-slate-400 text-sm">
              By submitting this form, you agree to our <strong>Privacy Policy</strong> and <strong>Terms of Service</strong>.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
