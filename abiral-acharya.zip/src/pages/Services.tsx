/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { 
  Stethoscope, 
  Baby, 
  Activity, 
  HeartPulse, 
  Syringe, 
  Video, 
  Ambulance,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { SERVICES } from '../constants';
import { cn } from '../lib/utils';

const ICON_MAP: Record<string, React.ReactNode> = {
  Stethoscope: <Stethoscope size={32} />,
  Baby: <Baby size={32} />,
  Activity: <Activity size={32} />,
  HeartPulse: <HeartPulse size={32} />,
  Syringe: <Syringe size={32} />,
  Video: <Video size={32} />,
  Ambulance: <Ambulance size={32} />,
};

export default function Services() {
  return (
    <div className="space-y-32 pb-32">
      {/* Header */}
      <section className="bg-slate-900 text-white pt-32 pb-48 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img
            src="https://picsum.photos/seed/clinic-bg/1920/1080"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10 text-center space-y-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-blue-300 text-xs font-bold uppercase tracking-widest border border-white/20"
          >
            <ShieldCheck size={14} />
            Premium Medical Facility
          </motion.div>
          <h1 className="text-5xl lg:text-7xl font-bold tracking-tight leading-tight max-w-4xl mx-auto">
            Comprehensive <span className="text-blue-400">Core Services</span> for Every Patient
          </h1>
          <p className="text-slate-400 text-xl max-w-2xl mx-auto">
            From routine checkups to emergency care, our specialized departments are equipped to provide the best clinical outcomes.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="max-w-7xl mx-auto px-10 lg:px-12 -mt-32 relative z-20">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {SERVICES.map((service, idx) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white p-12 rounded-[32px] shadow-2xl shadow-slate-200/50 border border-slate-100 hover:shadow-blue-100 transition-all group overflow-hidden relative"
            >
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-blue-50 rounded-full group-hover:scale-[3] transition-transform duration-700 opacity-50 z-0" />
              
              <div className="relative z-10 space-y-6">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-blue-100 font-bold italic">
                  {service.title.substring(0, 2)}
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-3">{service.title}</h3>
                  <p className="text-slate-500 text-lg leading-relaxed">
                    {service.description}
                  </p>
                </div>
                <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
                   <Link
                    to="/appointment"
                    className="inline-flex items-center gap-2 text-blue-600 font-bold text-sm hover:gap-3 transition-all"
                  >
                    Book Service
                    <ChevronRight size={16} />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Info Slice */}
      <section className="max-w-7xl mx-auto px-6 lg:px-8 bg-blue-50 rounded-[4rem] p-16 lg:p-24 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-white/40 -skew-x-12 translate-x-1/2" />
        <div className="grid lg:grid-cols-2 gap-16 items-center relative z-10">
          <div className="space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight">Need Urgent Assistance?</h2>
            <p className="text-xl text-slate-600 leading-relaxed">
              Our emergency department operates during clinic hours to handle acute medical needs without prior appointments.
            </p>
            <div className="flex gap-6">
              <a
                href="tel:+15559114357"
                className="bg-rose-600 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-rose-700 transition-all shadow-xl shadow-rose-200"
              >
                Call Emergency
              </a>
              <Link
                to="/appointment"
                className="bg-white text-blue-600 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-slate-50 transition-all border border-blue-100"
              >
                Schedule Checkup
              </Link>
            </div>
          </div>
          <div className="relative">
            <div className="bg-white p-12 rounded-[3.5rem] shadow-xl border border-slate-100 space-y-8">
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <div className="text-4xl font-bold text-blue-600 mb-2">24h</div>
                  <div className="text-slate-500 font-bold uppercase text-xs tracking-wider">Fast Response</div>
                </div>
                <div>
                  <div className="text-4xl font-bold text-emerald-600 mb-2">10k+</div>
                  <div className="text-slate-500 font-bold uppercase text-xs tracking-wider">Successful Cases</div>
                </div>
              </div>
              <div className="aspect-video rounded-3xl overflow-hidden shadow-inner bg-slate-100">
                <img
                  src="https://picsum.photos/seed/doctor-v2/600/400"
                  className="w-full h-full object-cover opacity-80"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
