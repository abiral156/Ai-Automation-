/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Phone, Mail, Instagram, Facebook, Twitter, Linkedin, MessageCircle, ArrowRight, Clock } from 'lucide-react';
import { APIProvider, Map, AdvancedMarker, Pin } from '@vis.gl/react-google-maps';

const API_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

export default function Contact() {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your message! We will get back to you soon.');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="space-y-32 pb-32">
      {/* Header */}
      <section className="bg-white border-b border-slate-100 pt-20 pb-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <div className="space-y-8">
              <span className="text-blue-600 font-bold uppercase tracking-[0.2em] text-sm">Contact Us</span>
              <h1 className="text-5xl lg:text-7xl font-bold tracking-tight text-slate-900 leading-tight">
                Always Here <br /> to <span className="text-blue-600">Assist You</span>
              </h1>
              <p className="text-xl text-slate-500 leading-relaxed max-w-xl">
                Have questions about our services or need to follow up on a visit? Our friendly team is ready to help you via phone, email, or message.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-8 pt-4">
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-3 text-slate-900 font-bold text-lg">
                    <div className="bg-blue-50 p-2 rounded-xl text-blue-600">
                      <Phone size={20} />
                    </div>
                    Calls
                  </div>
                  <p className="text-slate-500">+1 (555) 000-1111</p>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-3 text-slate-900 font-bold text-lg">
                    <div className="bg-emerald-50 p-2 rounded-xl text-emerald-600">
                      <MessageCircle size={20} />
                    </div>
                    WhatsApp
                  </div>
                  <p className="text-slate-500">+1 (555) 000-2222</p>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-3 text-slate-900 font-bold text-lg">
                    <div className="bg-rose-50 p-2 rounded-xl text-rose-600">
                      <Mail size={20} />
                    </div>
                    Email
                  </div>
                  <p className="text-slate-500">care@abiralacharya.com</p>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-3 text-slate-900 font-bold text-lg">
                    <div className="bg-amber-50 p-2 rounded-xl text-amber-600">
                      <Clock size={20} />
                    </div>
                    24/7 Service
                  </div>
                  <p className="text-slate-500">Emergency Line: 911</p>
                </div>
              </div>
            </div>

            <div className="relative">
              <form onSubmit={handleSubmit} className="bg-slate-900 p-10 lg:p-14 rounded-[3.5rem] shadow-2xl relative z-10 space-y-8">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 uppercase tracking-widest block ml-1">Your Name</label>
                  <input
                    required
                    type="text"
                    className="w-full bg-slate-800 border-transparent focus:border-blue-500 focus:bg-slate-700 rounded-2xl p-4 transition-all outline-none text-white text-lg"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 uppercase tracking-widest block ml-1">Email Address</label>
                  <input
                    required
                    type="email"
                    className="w-full bg-slate-800 border-transparent focus:border-blue-500 focus:bg-slate-700 rounded-2xl p-4 transition-all outline-none text-white text-lg"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 uppercase tracking-widest block ml-1">Message</label>
                  <textarea
                    required
                    rows={4}
                    className="w-full bg-slate-800 border-transparent focus:border-blue-500 focus:bg-slate-700 rounded-2xl p-4 transition-all outline-none text-white text-lg resize-none"
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-5 rounded-[2rem] font-bold text-xl hover:bg-blue-700 transition-all shadow-xl flex items-center justify-center gap-3 group"
                >
                  Send Message
                  <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                </button>
              </form>
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-500/20 blur-3xl rounded-full" />
              <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-emerald-500/10 blur-3xl rounded-full" />
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-5 gap-12 items-stretch">
          <div className="lg:col-span-2 bg-blue-600 rounded-[3rem] p-12 lg:p-16 text-white space-y-10 shadow-2xl shadow-blue-200">
            <h2 className="text-4xl font-bold tracking-tight">Visit Us</h2>
            <p className="text-blue-100 text-lg leading-relaxed">
              We are located in the heart of downtown, easily accessible by public transport and with ample parking for patients.
            </p>
            <div className="space-y-8">
              <div className="flex gap-4">
                <MapPin className="text-blue-300 shrink-0 mt-1" size={24} />
                <p className="text-xl font-bold">123 Medical Drive, Health Plaza, Suite 400, Chicago, IL 60601</p>
              </div>
              <div className="flex flex-wrap gap-4 pt-8">
                {[Facebook, Twitter, Instagram, Linkedin].map((Icon, idx) => (
                  <a
                    key={idx}
                    href="#"
                    className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center hover:bg-white hover:text-blue-600 transition-all outline outline-1 outline-white/20"
                  >
                    <Icon size={24} />
                  </a>
                ))}
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-3 min-h-[500px] rounded-[3rem] overflow-hidden shadow-2xl border border-slate-100 relative group">
            {hasValidKey ? (
              <APIProvider apiKey={API_KEY} version="weekly">
                <Map
                  defaultCenter={{lat: 41.8781, lng: -87.6298}}
                  defaultZoom={14}
                  mapId="CONTACT_MAP"
                  internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                  style={{width: '100%', height: '100%'}}
                >
                  <AdvancedMarker position={{lat: 41.8781, lng: -87.6298}}>
                    <Pin background="#2563eb" glyphColor="#fff" />
                  </AdvancedMarker>
                </Map>
              </APIProvider>
            ) : (
              <div className="absolute inset-0 bg-slate-50 flex flex-col items-center justify-center p-10 text-center space-y-6">
                <div className="bg-white p-6 rounded-[2.5rem] shadow-xl border border-slate-100 max-w-sm">
                  <MapPin size={48} className="text-blue-600 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Location Map</h3>
                  <p className="text-slate-500">Google Maps API key is required to view the interactive map. Please add it as a secret.</p>
                  <div className="mt-6 pt-6 border-t border-slate-100 text-xs font-bold uppercase tracking-widest text-slate-400">
                    41.8781° N, 87.6298° W
                  </div>
                </div>
              </div>
            )}
            <div className="absolute top-6 right-6 bg-white/80 backdrop-blur-md px-6 py-3 rounded-full text-slate-900 font-bold shadow-xl border border-white/50 text-sm">
              Abiral Acharya Clinic
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
