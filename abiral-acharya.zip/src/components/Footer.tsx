/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Link } from 'react-router-dom';
import { HeartPulse, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-slate-200 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                <HeartPulse size={20} />
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-900">
                Abiral <span className="text-blue-600">Acharya</span>
              </span>
            </Link>
            <p className="text-slate-500 text-sm leading-relaxed">
              Providing specialized medical care with a focus on patient comfort, advanced diagnostics, and personalized treatment plans for your family.
            </p>
          </div>

          <div>
            <h3 className="text-slate-900 font-bold mb-6 text-sm uppercase tracking-wider">Quick Links</h3>
            <ul className="space-y-3 text-sm">
              {['Home', 'About Us', 'Services', 'Contact'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-slate-500 hover:text-blue-600 transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-slate-900 font-bold mb-6 text-sm uppercase tracking-wider">Clinic Hours</h3>
            <ul className="space-y-3 text-sm text-slate-500">
              <li className="flex justify-between border-b border-slate-50 pb-2">
                <span>Mon — Fri</span>
                <span className="text-slate-900 font-medium">8:00 AM - 8:00 PM</span>
              </li>
              <li className="flex justify-between border-b border-slate-50 pb-2">
                <span>Saturday</span>
                <span className="text-slate-900 font-medium">9:00 AM - 1:00 PM</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-slate-900 font-bold mb-6 text-sm uppercase tracking-wider">Address</h3>
            <p className="text-sm text-slate-500 leading-relaxed">
              122 Medical Plaza, <br/>Downtown Chicago, IL 60601
            </p>
            <div className="mt-4 flex items-center gap-4 text-slate-400">
              {[Facebook, Twitter, Instagram].map((Icon, idx) => (
                <a key={idx} href="#" className="hover:text-blue-600 transition-colors">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] uppercase font-bold tracking-widest text-slate-400">
          <p>© {new Date().getFullYear()} Abiral Acharya. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-blue-600">Privacy Policy</a>
            <a href="#" className="hover:text-blue-600">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
